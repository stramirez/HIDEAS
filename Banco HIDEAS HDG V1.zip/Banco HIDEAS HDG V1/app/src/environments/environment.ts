// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyAeffi_AIbesGmmGsUPFB0jHRsWOINHaM8",
    authDomain: "proyectoangular-6cadc.firebaseapp.com",
    projectId: "proyectoangular-6cadc",
    storageBucket: "proyectoangular-6cadc.appspot.com",
    messagingSenderId: "411586153735",
    appId: "1:411586153735:web:ca08288daf1ec92d7509a2",
    measurementId: "G-06V953J6R4"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
