import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HideasService } from 'src/app/services/hideas.service';


@Component({
  selector: 'app-categoria',
  templateUrl: './categoria.component.html',
  styleUrls: ['./categoria.component.css']
})
export class CategoriaComponent implements OnInit {

  categorias:any = []
  idEdit: any
  edit: Boolean = false

  constructor(private ruta: ActivatedRoute, private servicio: HideasService) { }

  ngOnInit(): void {
    this.listar()
  }

  nuevaCategoria = {
    id:'',
    descripcion: ''
  }

  clear(){
    this.nuevaCategoria.id = ''
    this.nuevaCategoria.descripcion = ''
  }

  listar(){
    //Hacemos consulta a base de datos para obtener las categorias
    this.servicio.getAllCats( )
      .subscribe((categorias) => {
        this.categorias = categorias        
      }, (error) => {
        console.error('Error getting categorias: ', error)
      })
  }

  registrar(){
    console.log(this.nuevaCategoria);
    if (!this.edit) {
      this.servicio.saveCategoria(this.nuevaCategoria).subscribe(
        (res)=> {
          console.log(res);   
          this.listar()  
        },
        (err) => {
          console.log(err);
        }
      )
    } else {
      this.edit = false
      this.servicio.editCat(this.idEdit, this.nuevaCategoria).subscribe(
        (res)=> {
          console.log(res);  
          this.listar()    
        },
        (err) => {
          console.log(err);
        }
      )
    }
    this.clear()
  }

  eliminar(catSelec:any){
    this.servicio.deleteCat(catSelec).subscribe(
      (res)=>{
        const index = this.categorias.indexOf(catSelec)
        if(index > -1){
          this.categorias.splice(index,1);
        }
      },
      (err)=> {
        console.error('Error deleting categoria: ', err);
      }
    )
  }

  editar(catSelec:any){
    this.edit = true
    this.idEdit = catSelec._id
    this.nuevaCategoria.id = catSelec.id
    this.nuevaCategoria.descripcion = catSelec.descripcion
  }
}
