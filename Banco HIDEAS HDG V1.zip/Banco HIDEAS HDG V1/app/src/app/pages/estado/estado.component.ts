import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HideasService } from 'src/app/services/hideas.service';

@Component({
  selector: 'app-estado',
  templateUrl: './estado.component.html',
  styleUrls: ['./estado.component.css']
})
export class EstadoComponent implements OnInit {

  estados:any = []
  idEstado:any
  edit: Boolean = false

  constructor(private ruta: ActivatedRoute, private servicio: HideasService) { }

  ngOnInit(): void {
    this.listar()
  }

  nuevoEstado = {
    id:'',
    descripcion: ''
  }

  clear(){
    this.nuevoEstado.id = ''
    this.nuevoEstado.descripcion = ''
  }

  listar(){
    //Hacemos consulta a base de datos para obtener los estados
    this.servicio.getAllEstados( )
      .subscribe((estados) => {
        this.estados = estados        
      }, (error) => {
        console.error('Error getting estados: ', error)
      })
  }

  registrar(){
    console.log(this.nuevoEstado);
    if (!this.edit) {
      this.servicio.saveEstado(this.nuevoEstado).subscribe(
        (res)=> {
          console.log(res);        
          this.listar()
        },
        (err) => {
          console.log(err);
        }
      )
    } else {
      this.edit = false
      this.servicio.editEstado(this.idEstado, this.nuevoEstado).subscribe(
        (res)=> {
          console.log(res);   
          this.listar()    
        },
        (err) => {
          console.log(err);
        }
      )
    }
    this.clear() 
  }

  eliminar(estadoSelec:any){
    this.servicio.deleteEstado(estadoSelec).subscribe(
      (res)=>{
        const index = this.estados.indexOf(estadoSelec)
        if(index > -1){
          this.estados.splice(index,1);
        }
      },
      (err)=> {
        console.error('Error deleting estado: ', err);
      }
    )
  }

  editar(estadoSelec:any){
    this.edit = true
    this.idEstado = estadoSelec._id
    this.nuevoEstado.id = estadoSelec.id
    this.nuevoEstado.descripcion = estadoSelec.descripcion
  }

}
