import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import * as moment from 'moment'
import { HideasService } from 'src/app/services/hideas.service';

@Component({
  selector: 'app-idea',
  templateUrl: './idea.component.html',
  styleUrls: ['./idea.component.css']
})
export class IdeaComponent implements OnInit {
  
  estados:any = []
  categorias:any = []
  fecha_cre:String
  fecha_mod:String

  constructor(private router: Router, private servicio: HideasService) { }

    ngOnInit(): void {
    
    this.Info.fecha_creacion = moment().format("DD/MM/YYYY")
    this.Info.fecha_modificacion = moment().format("DD/MM/YYYY HH:mm:ss")
    //Hacemos consulta a base de datos para obtener las categorias
    this.servicio.getAllCats( )
    .subscribe((categorias) => {
      this.categorias = categorias        
    }, (error) => {
      console.error('Error getting categorias: ', error)
    })

      //Hacemos consulta a base de datos para obtener los estados
      this.servicio.getAllEstados( )
      .subscribe((estados) => {
        this.estados = estados        
      }, (error) => {
        console.error('Error getting estados: ', error)
      })
    }

    Info = {
      id:"",
      categoria :"",
      id_proyecto:"",
      titulo_idea:"",
      fecha_creacion:"",
      descripcion:"",
      estado:"",
      tecnologia:"",
      inversion_prevista:"",
      responsable:"",
      fecha_modificacion:"",
      propietario:"",
      //hora_mod:"",
    }
    InfoValidator = {
      id:false,
      categoria:false,
      id_proyecto:false,
      titulo_idea:false,
      fecha_creacion:false,
      descripcion:false,
      estado:false,
      tecnologia:false,
      inversion_prevista:false,
      responsable:false,
      fecha_modificacion:false,
      propietario:false,
      //hora_mod:false,
    }
    valid_idea() {
      // Validate info.
      if (this.Info.id === ""){
        console.log("ID vacío")
        this.InfoValidator.id=true;
      }else{
        this.InfoValidator.id=false;
      }
      if (this.Info.categoria === ""){
        console.log("Categoria vacía")
        this.InfoValidator.categoria=true;
      }else{
         this.InfoValidator.categoria=false;
      }
      //Validar que los camps no estan vacios y enonces ir a home
      if(this.Info.id !== "" && this.Info.categoria !== ""){
        localStorage.setItem("Info",JSON.stringify(this.Info))
        console.log(this.Info);
        
        //if (accion = 'save'){
          this.servicio.saveIdea(this.Info).subscribe(
            (res)=> {
              console.log(res);        
            },
            (err) => {
              console.log(err);
            }
          )
          /*} else if (accion = 'edit'){
            this.servicio.editIdea(this.Info).subscribe(
              (res)=> {
                console.log(res);        
              },
              (err) => {
                console.log(err);
              }
          )
        }*/
        this.router.navigate(['/'])
      }
    }
  }

