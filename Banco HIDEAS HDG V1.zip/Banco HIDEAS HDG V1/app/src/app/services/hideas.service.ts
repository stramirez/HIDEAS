import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HideasService {

  constructor(private http: HttpClient) { }

  getAll() {
    return this.http.get('http://localhost:3000/idea')
  }

  saveCategoria(categoria: any) {
    return this.http.post<any>('http://localhost:3000/categoria', categoria)
  }

  getAllCats() {
    return this.http.get('http://localhost:3000/categoria')
  }

  deleteCat(cat: any) { 
    const _id = cat._id
    return this.http.delete<any>('http://localhost:3000/categoria/'+_id)
  }

  editCat(id: any, cat: any) { 
    return this.http.put<any>('http://localhost:3000/categoria/'+id, cat)
  }

  saveEstado(estado: any) {
    return this.http.post<any>('http://localhost:3000/estado', estado)
  }

  getAllEstados() {
    return this.http.get('http://localhost:3000/estado')
  }

  deleteEstado(cat: any) { 
    const _id = cat._id
    return this.http.delete<any>('http://localhost:3000/estado/'+_id)
  }

  editEstado(id: any, estado: any) { 
    const _id = estado._id
    return this.http.put<any>('http://localhost:3000/estado/'+id, estado)
  }

  saveIdea(idea: any) {
    return this.http.post<any>('http://localhost:3000/idea', idea)
  }

  deleteIdea(idea: any) { 
    const _id = idea._id
    return this.http.delete<any>('http://localhost:3000/idea/'+_id)
  }

  editIdea(idea: any) { 
    const _id = idea._id
    return this.http.put<any>('http://localhost:3000/idea/'+_id, idea)
  }

}
